import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: Principal(),
    );
  }
}
List<Persona> _personas = [
  Persona('Yarely Karime', 'Sandoval', '20197853'),
  Persona('Gabriela Noemi', 'Galicia', '20195268'),
  Persona('Rosa', 'Isais', '20162345'),
  Persona('Gael', 'Sandoval', '20244977')
];

final nom = TextEditingController();
final ape = TextEditingController();
final cue = TextEditingController();

String tnom = '';
String tape = '';
String tcue = '';

class Principal extends StatefulWidget {
  @override
  State<Principal> createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Listado de Alumnos'),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => Principal2()));
        },

        child: Icon(Icons.people_alt_outlined),
        backgroundColor: Colors.green),

      body: ListView.builder(
        itemCount: _personas.length,
        itemBuilder: (BuildContext context, int index){
          return ListTile(
            title:
            Text(_personas[index].name + ' '+ _personas[index].lastname),
            subtitle: Text(_personas[index].cuenta),
            leading: CircleAvatar(
              child: Text(_personas[index].name.substring(0,1)),
            ),
            trailing: Icon(Icons.arrow_forward_ios),
          );
        },)
    );
  }
}

class Principal2 extends StatefulWidget {
  @override
  State<Principal2> createState() => _Principal2State();
}

class _Principal2State extends State<Principal2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Agregar alumno'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: TextField(
                controller: nom,
                decoration: InputDecoration(
                hintText: 'Nombre',
                filled: true,
                fillColor: Colors.white),
              ),
            ),
            SizedBox(height: 30.0),
            Container(
              child: TextField(
                controller: ape,
                decoration: InputDecoration(
                hintText: 'Apellidos',
                filled: true,
                fillColor: Colors.white),
              ),
            ),
            SizedBox(height: 30.0),
            Container(
              child: TextField(
                controller: cue,
                decoration: InputDecoration(
                hintText: 'No. Cuenta',
                filled: true,
                fillColor: Colors.white),
              ),
            ),
            SizedBox(height: 50.0),
            Container(
              child: OutlinedButton(
                child: Text('Guardar', style: TextStyle(fontSize: 25.0, color: Colors.white),),
                style: OutlinedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: (){
                  tnom = nom.text;
                  tape = ape.text;
                  tcue = cue.text;
                  _personas.add(Persona(tnom, tape, tcue));
                  Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => Principal()));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class Persona{
  String name;
  String lastname;
  String cuenta;

  Persona(this.name, this.lastname, this.cuenta);
}